// Import our custom CSS
import '../sass/main.scss';
// Components
import './components/index';

// Import javascript file as needed
import * as bootstrap from 'bootstrap';

// pages
import Dashboard from './pages/Dashboard';
import AddStory from './pages/AddStory';
import About from './pages/About';

const routes = {
  '/': Dashboard,
  '/add-story.html': AddStory,
  '/about.html': About,
};

const detectRoute = () => routes[window.location.pathname];

window.addEventListener('DOMContentLoaded', async () => {
  const route = detectRoute();
  route.init();
});
