const Dashboard = {
  async init() {
    await this._initialData();
  },

  async _initialData() {
    const fetchRecords = await fetch('/data/data.json');
    const responseRecords = await fetchRecords.json();

    const storyCards = document.querySelector('story-cards');

    let html = '';

    responseRecords.listStory.map((story) => {
      html += `
            <story-card
              id="${story.id}"
              name="${story.name}"
              description="${story.description}"
              photoUrl="${story.photoUrl}"
              createdAt="${story.createdAt}"
            ></story-card>
        `;
    });

    const dataField = document.querySelector('.data-field');

    dataField.innerHTML = html;
  },
};

export default Dashboard;
