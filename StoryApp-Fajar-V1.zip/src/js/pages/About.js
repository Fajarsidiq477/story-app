const About = {
  async init() {},
};

export default About;
