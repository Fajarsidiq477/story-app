const AddStory = {
  async init() {
    const formAddStory = document.querySelector('#form-add-story');
    formAddStory.addEventListener('submit', (e) => {
      e.preventDefault();

      const storyURLSpan = document.querySelector('#storyURLSpan');

      const data = {
        imgUrl: storyURLSpan.innerText,
        description: document.querySelector('#descriptionInput').value,
      };

      formAddStory.classList.add('was-validated');
      console.log(data);
    });
  },
};

export default AddStory;
