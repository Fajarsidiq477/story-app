import { html } from 'lit';
import LitWithoutShadowDom from './base/LitWithoutShadowDom';

class NavLinks extends LitWithoutShadowDom {
  render() {
    return html`
      <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
        <nav-link to="/" content="Dashboard"></nav-link>
        <nav-link to="/add-story.html" content="Add Story"></nav-link>
        <nav-link to="/about.html" content="About"></nav-link>
      </ul>
    `;
  }
}

customElements.define('nav-links', NavLinks);
