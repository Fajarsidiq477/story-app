import { html } from 'lit';
import LitWithoutShadowDom from './base/LitWithoutShadowDom';

class StoryCard extends LitWithoutShadowDom {
  static properties = {
    id: {
      type: String,
      reflect: true,
    },
    name: {
      type: String,
      reflect: true,
    },
    photoUrl: {
      type: String,
      reflect: true,
    },
    createdAt: {
      type: String,
      reflect: true,
    },
    description: {
      type: String,
      reflect: true,
    },
  };

  constructor() {
    super();

    this._checkAvailabilityProperty();
  }

  _checkAvailabilityProperty() {
    if (!this.hasAttribute('id')) {
      throw new Error(
        `Atribut "id" harus diterapkan pada elemen ${this.localName}`
      );
    }
    if (!this.hasAttribute('name')) {
      throw new Error(
        `Atribut "name" harus diterapkan pada elemen ${this.localName}`
      );
    }
    if (!this.hasAttribute('photoUrl')) {
      throw new Error(
        `Atribut "photoUrl" harus diterapkan pada elemen ${this.localName}`
      );
    }

    if (!this.hasAttribute('createdAt')) {
      throw new Error(
        `Atribut "createdAt" harus diterapkan pada elemen ${this.localName}`
      );
    }

    if (!this.hasAttribute('description')) {
      throw new Error(
        `Atribut "description" harus diterapkan pada elemen ${this.localName}`
      );
    }
  }

  render() {
    return html`
      <div class="card mb-3">
        <div
          class="card-header d-flex justify-content-between align-items-center"
        >
          <div class="d-flex align-items-center">
            <img
              src="http://placehold.co/50x50"
              class="me-2 rounded-circle"
              alt=""
            />
            <a
              @click=${() => {
                console.log(this.id);
              }}
              >${this.name}</a
            >
          </div>
          <a class="btn shadow-sm">...</a>
        </div>
        <div class="card-body">
          <img
            src="${this.photoUrl}"
            class="img-fluid mb-2"
            alt="story image"
          />
          <p class="createdAt fw-bold mb-2">${this.createdAt}</p>
          <p class="description mb-1">${this.description}</p>
        </div>
      </div>
    `;
  }
}

customElements.define('story-card', StoryCard);
