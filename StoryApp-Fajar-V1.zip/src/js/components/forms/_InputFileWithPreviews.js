import { html } from 'lit';
import LitWithoutShadowDom from '../base/LitWithoutShadowDom';

class InputFileWithPreviews extends LitWithoutShadowDom {
  render() {
    return html`
      <div
        class="w-100 mx-auto text-white mb-3 d-none"
        style="
                  min-height: 15rem;
                  background-repeat: no-repeat;
                  background-position: center;
                  background-size: contain;
                "
        id="storyPreview"
      ></div>

      <div class="mb-3">
        <label for="StoryInput" class="form-label">Photo</label>
        <input
          class="form-control"
          type="file"
          id="storyInput"
          required
          accept="image/*"
          @change=${this._updatePreviewStory}
        />
        <span class="d-none" id="storyURLSpan"></span>
      </div>
    `;
  }

  _updatePreviewStory() {
    const StoryInput = document.querySelector('#storyInput');
    const storyPreview = document.querySelector('#storyPreview');

    const storyData = StoryInput.files[0];

    const reader = new FileReader();
    reader.readAsDataURL(storyData);

    reader.onload = (e) => {
      storyPreview.classList.remove('d-none');
      storyPreview.style.backgroundImage = `url(${e.target.result})`;

      const storyURLSpan = document.querySelector('#storyURLSpan');
      storyURLSpan.innerText = e.target.result;
    };
  }
}

customElements.define('input-file-with-previews', InputFileWithPreviews);
